/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define Y_STEP_Pin GPIO_PIN_5
#define Y_STEP_GPIO_Port GPIOE
#define Y_DIR_Pin GPIO_PIN_6
#define Y_DIR_GPIO_Port GPIOE
#define X_Limit_Pin GPIO_PIN_6
#define X_Limit_GPIO_Port GPIOG
#define X_Limit_EXTI_IRQn EXTI9_5_IRQn
#define Y_Limit_Pin GPIO_PIN_7
#define Y_Limit_GPIO_Port GPIOG
#define Y_Limit_EXTI_IRQn EXTI9_5_IRQn
#define X_STEP_Pin GPIO_PIN_6
#define X_STEP_GPIO_Port GPIOB
#define X_DIR_Pin GPIO_PIN_7
#define X_DIR_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
